# Channel Availability Test Script

## 📋 Descripción

Este script automatiza las pruebas de disponibilidad de canales WiFi en dispositivos HGU (Home Gateway Unit) de Askey WiFi 5 y 6. Interactúa con la interfaz web del dispositivo para cambiar automáticamente entre diferentes canales de 2.4GHz y 5GHz, capturando pantallas tanto de la interfaz web como del software inSSIDer durante el proceso.

## ⚡ Instalación y Ejecución Rápida

### Para usuarios nuevos (método más fácil):

1. **Descarga** todos los archivos del proyecto
2. **Ejecuta** `run.bat` como administrador (click derecho → "Ejecutar como administrador")
3. **Espera** a que se instalen automáticamente todas las dependencias
4. **¡Listo!** El script comenzará a ejecutarse

```batch
# Solo necesitas hacer esto:
run.bat
```

## 🔧 Requisitos del Sistema

- **Sistema Operativo**: Windows 10/11
- **Permisos**: Administrador (solo para la primera instalación)
- **Conexión**: Internet (para descargar dependencias)
- **Software adicional**: inSSIDer Home instalado en la ruta por defecto

## 📁 Estructura del Proyecto

```
proyecto/
├── channels.js              # Script principal
├── channels_functions.js    # Funciones auxiliares
├── install_deps.ps1         # Instalador de dependencias
├── run.bat                  # Lanzador principal
├── package.json             # Configuración del proyecto
├── package-lock.json        # Dependencias bloqueadas
└── README.md               # Esta documentación
```

## 🚀 Guía de Uso

### Método 1: Ejecución Automática (Recomendado)

```batch
# Ejecutar como administrador la primera vez
run.bat
```

### Método 2: Instalación Manual

Si prefieres instalar manualmente las dependencias:

```bash
# 1. Instalar Node.js desde https://nodejs.org/ (versión 18 o superior)

# 2. Instalar dependencias
npm install

# 3. Instalar navegador Chromium
npx puppeteer browsers install chrome

# 4. Ejecutar script
node channels.js
```

## 📊 Funcionalidades

### ✅ Automatización Completa
- Instalación automática de Node.js
- Instalación de dependencias npm
- Descarga automática del navegador Chromium
- Configuración del entorno completa

### 🌐 Gestión Web Automática
- Login automático al dispositivo (IP: 192.168.1.1)
- Navegación por la interfaz de configuración
- Cambio automático de canales 2.4GHz y 5GHz
- Configuración de diferentes anchos de banda

### 📸 Captura de Pantallas
- Screenshots de la interfaz web
- Capturas de inSSIDer automáticas
- Organización automática por frecuencia y ancho de banda
- Nomenclatura sistemática de archivos

### 📁 Organización Automática
Las capturas se guardan en:
```
Desktop/Channel_availability_YYYY-MM-DD/
├── 2,4GHz/
│   ├── 20MHz/
│   │   ├── WEB/
│   │   └── INSSIDER/
│   └── 20MHz_40MHz/
│       ├── WEB/
│       └── INSSIDER/
└── 5GHz/
    ├── 20MHz/
    ├── 40MHz/
    └── 80MHz/
```

## ⚙️ Configuración

### Configuración del Dispositivo
- **IP del dispositivo**: 192.168.1.1 (modificable en `channels_functions.js`)
- **Autenticación**: Solicitará contraseña durante la ejecución
- **Timeout**: 120 segundos para operaciones de red

### Configuración de inSSIDer
- **Ruta por defecto**: `C:\Program Files (x86)\MetaGeek\inSSIDer Home\inSSIDerHome.exe`
- **Requisito**: Debe estar instalado antes de ejecutar el script
- **Uso**: Se abre automáticamente, filtrar manualmente por SSID mostrado

## 🛠️ Solución de Problemas

### Problemas Comunes y Soluciones

#### ❌ "Node.js no encontrado"
```bash
# Solución automática: ejecutar run.bat como administrador
# Solución manual: instalar desde https://nodejs.org/
```

#### ❌ "Could not find Chromium"
```bash
# Ejecutar en terminal:
npx puppeteer browsers install chrome

# O reinstalar completamente:
npm install puppeteer --force
```

#### ❌ "No se pudo acceder a la página del dispositivo"
- Verificar que el dispositivo esté conectado y en 192.168.1.1
- Comprobar conectividad de red
- Verificar que no haya proxy o firewall bloqueando

#### ❌ "Contraseña incorrecta"
- Verificar credenciales del dispositivo
- Asegurar que no hay bloqueo por intentos fallidos

#### ❌ "inSSIDer no se abre"
- Verificar instalación en la ruta por defecto
- Instalar inSSIDer Home desde el sitio oficial
- Ejecutar manualmente para verificar funcionamiento

### Logs y Diagnóstico

El script proporciona información detallada durante la ejecución:
- ✅ Estados de instalación
- 🔍 Progreso de navegación web
- 📸 Confirmación de capturas
- ❌ Errores específicos con soluciones sugeridas

## 📋 Requisitos de Hardware

### Dispositivos Compatibles
- **Modelos probados**: HGU Askey WiFi 5 y 6
- **Interfaz web**: Compatible con framework específico de Askey
- **Advertencia**: Puede no funcionar con otros fabricantes

### Requisitos del PC
- **RAM**: Mínimo 4GB (recomendado 8GB)
- **Espacio**: 500MB libres (para dependencias y capturas)
- **Resolución**: Mínimo 1366x768 (para capturas consistentes)

## 🔄 Actualizaciones

### Actualización Manual
```bash
# Actualizar dependencias
npm update

# Reinstalar navegador si hay problemas
npx puppeteer browsers install chrome --force
```

### Verificación de Estado
```bash
# Verificar instalación
node -e "require('puppeteer').launch().then(() => console.log('✅ Todo OK'))"
```

## 🤝 Soporte

### Antes de Reportar Problemas
1. **Ejecutar** `run.bat` como administrador
2. **Verificar** que inSSIDer está instalado
3. **Comprobar** conectividad con el dispositivo
4. **Revisar** los logs en consola

### Información Útil para Soporte
- Versión de Windows
- Versión de Node.js (`node -v`)
- Modelo exacto del dispositivo
- Mensaje de error completo
- Logs de consola

## 📝 Notas Importantes

### ⚠️ Advertencias
- **Primera ejecución**: Requiere permisos de administrador
- **Conectividad**: Mantener conexión estable durante las pruebas
- **Duración**: El proceso completo puede tomar 30-60 minutos
- **inSSIDer**: Debe filtrarse manualmente por el SSID mostrado

### 💡 Consejos
- Ejecutar en horarios de poco tráfico de red
- Cerrar aplicaciones innecesarias durante la ejecución
- Mantener el dispositivo encendido y estable
- No interrumpir el proceso una vez iniciado

### 🔒 Seguridad
- Las credenciales se solicitan interactivamente (no se almacenan)
- Solo se accede a la IP del dispositivo configurada
- No se envían datos a servicios externos

---

## 📞 Contacto y Contribuciones

Este script es una herramienta especializada para pruebas técnicas. Para mejoras o modificaciones específicas, considerar las particularidades del hardware y la interfaz web del dispositivo objetivo.

**Versión**: 1.4  
**Compatibilidad**: Windows 10/11, Node.js 18+  
**Última actualización**: 2025